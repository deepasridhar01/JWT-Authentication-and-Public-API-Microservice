require('dotenv').config({ path: './src/.env' });
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const routes = require('./routes');

dotenv.config();

const app = express();
app.use(express.json());

// Connect to MongoDB
mongoose.connect(process.env.DB_CONNECTION, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log('Connected to public API database'))
  .catch((err) => console.log('Database connection error: ', err));

// Routes
app.use('/api/public', routes);

// Start the server
const PORT = process.env.PORT || 4001;
app.listen(PORT, () => console.log(`Public API service running on port ${PORT}`));
 
