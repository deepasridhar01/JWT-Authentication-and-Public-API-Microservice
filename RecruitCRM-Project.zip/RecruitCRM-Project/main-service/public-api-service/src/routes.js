const express = require('express');
const router = express.Router();
const User = require('../common/models/User');
const Candidate = require('../common/models/Candidate');


// Middleware to check API key
function checkApiKey(req, res, next) {
    const apiKey = req.header('x-api-key');
    if (apiKey !== process.env.API_KEY) {
        return res.status(403).json({ message: 'Forbidden: Invalid API Key' });
    }
    next();
}

// Get user profile by API key
router.post('/profile', checkApiKey, async (req, res) => {
    const { email } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json({
            id: user._id,
            first_name: user.first_name,
            last_name: user.last_name,
            email: user.email,
        });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Get candidates associated with a user by API key
router.get('/candidate', checkApiKey, async (req, res) => {
    const { email } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const candidates = await Candidate.find({ user_id: user._id });
        res.json(candidates);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
 
