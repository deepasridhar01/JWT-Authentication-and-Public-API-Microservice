require('dotenv').config({ path: '../.env' });


const mongoose = require('mongoose');
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Debugging: Print environment variables
console.log('Environment Variables Loaded:');
console.log('PORT:', process.env.PORT);
console.log('DB_CONNECTION:', process.env.DB_CONNECTION);

// Connect to MongoDB
if (!process.env.DB_CONNECTION) {
  console.error('DB_CONNECTION is not defined in the .env file.');
  process.exit(1);
}

mongoose.connect(process.env.DB_CONNECTION, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB Connection Error:', err));

// Middleware
app.use(express.json());

// Routes
const userRoutes = require('./routes/users');
const candidateRoutes = require('./routes/candidates');

app.use('/api', userRoutes);
app.use('/api', candidateRoutes);

// Start server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
