const express = require('express');
const router = express.Router();
const Candidate = require('../models/Candidate');
const authenticateToken = require('../middleware/authMiddleware');

// Add a candidate
router.post('/candidate', authenticateToken, async (req, res) => {
    const { first_name, last_name, email } = req.body;
    const user_id = req.user.id;

    try {
        const newCandidate = new Candidate({
            first_name,
            last_name,
            email,
            user_id,
        });

        await newCandidate.save();
        res.status(201).json({ message: 'Candidate added successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

// Get candidates for the current user
router.get('/candidate', authenticateToken, async (req, res) => {
    try {
        const candidates = await Candidate.find({ user_id: req.user.id });
        res.json(candidates);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
});

module.exports = router;
