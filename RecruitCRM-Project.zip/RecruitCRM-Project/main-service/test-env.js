require('dotenv').config();
console.log('PORT:', process.env.PORT);
console.log('DB_CONNECTION:', process.env.DB_CONNECTION);
